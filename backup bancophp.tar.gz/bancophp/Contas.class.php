<?php
class Contas {

	var $numAge;
	var $numConta;
	var $nome;
	var $saldo;

	function selecionar($query) {
		$con = $this->conectar();

		$res = mysql_query($query,$con) or die ("Erro!!");
		$qtd = mysql_num_rows($res);
		echo "Quantidade de registros encontrados: " . $qtd . "<br>";
		if ($qtd == 0) {
			return 0;
		} else {
			$conta = mysql_fetch_array($res);
			return $conta['ID'];
		}
		mysql_close($con);
	}
			
	function exibeDados() {
		$saida  = "<h1> Dados da conta </h1>";
		$saida .= "Agência " . $this->numAge   . "<br>";
		$saida .= "Conta"    . $this->numConta . "<br>";
		$saida .= "Cliente"  . $this->nome     . "<br>";
		
		$saida .= "Saldo atual: R$" . number_format($this->saldo,3,",",".") . "|<br>";
		
		return $saida;
	}
	
	function saque($valor, $idconta) {
		$con = $this->conectar();
		$sel = "SELECT * FROM contas WHERE ID=" . $idconta . ";";
		$res = mysql_query($sel, $con) or die ("Erro: " . mysql_error($con) . $sel);
		$ctt = mysql_fetch_array($res);

		//echo "Cliente: " . $ctt['nome']    . "<br>";
		//echo "Agência: " . $ctt['agencia'] . "<br>";
		//echo "Conta: "   . $ctt['conta']   . "<br>";
		//echo "Saldo Anterior: " . $ctt['saldo'] . "<br>";

		$this->saldo = $ctt['saldo'];
		
		if ($this->saldo >= $valor) {
			$this->saldo -= $valor; // Tira o valor do saldo !
			$upd = "UPDATE contas SET saldo = " . $this->saldo . " WHERE ID= " . $idconta. ";";
			mysql_query($upd,$con) or die("Erro !!!");
			echo "Saque realizado: R$ " . $valor;
            echo "<br>Saldo atual: R$ " . $this->saldo;

		} else {
			echo "Saldo insuficiente para o saque: R$ " . $ctt['saldo'];
			echo "<br>Valor Solicitado: R$ " . $valor;
		}
		mysql_close($con);
	}
	
	function deposito($valor, $idconta) {
		$con = $this->conectar();

		$sel = "SELECT * FROM contas WHERE ID=" . $idconta . ";";
		$res = mysql_query($sel, $con) or die ("Erro: " . mysql_error($con) . $sel);
		$ctt = mysql_fetch_array($res);

		  echo "Cliente: " . $ctt['nome']    . "<br>";
		  echo "Agência: " . $ctt['agencia'] . "<br>";
		  echo "Conta: "   . $ctt['conta']   . "<br>";
		  echo "Saldo anterior: R$ " . $ctt['saldo'] . "<br>";

			$this->saldo = $ctt['saldo'];
			$this->saldo += $valor;

			$upd = "UPDATE contas SET saldo = " . $this->saldo . " WHERE ID= " . $idconta. ";";
			echo "Deposito de R$ " . $valor . " efetuado com sucesso !";
			echo "<br> Seu saldo atual é de R$ " . $ctt['saldo'] += $valor; //Faz a soma do saldo anterior com o valor depositado.

			mysql_query($upd,$con) or die("Erro !!!");

		mysql_close($con);
	}
	
	function conectar () {
		$server  = "localhost";
		$usuario = "daniel";
		$senha   = "daniel";
		$banco   = "daniel_contas";
		$charset = "utf8";
		
		$con = mysql_connect($server, $usuario, $senha) or die ("Erro 7: " . mysql_error());
		$dbase = mysql_select_db($banco) or die ("Error: " . mysql_error($con));
		mysql_set_charset($charset);
		
		return $con;
	}
}
?>