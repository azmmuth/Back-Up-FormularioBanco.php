<html>
	<head>
		<title>Banco ETEC</title>
		<meta charset="UTF-8">
		<link type="text/css" rel="stylesheet" href="style.css">
	</head>
	<body>
		<div class="container">
		<?php
		$acao = isset($_GET['acao']) ? $_GET['acao'] : "";
		
		if ($acao == "") {
		?>
			<h2>Escolha uma das opções</h2>
			<a href="?acao=abrir">Abertura de Conta</a><br>
			<a href="?acao=conta">Movimentar Conta</a><br>
		<?php
		}
		else if ($acao == "movim") {
			if ($_POST['conta'] != "" && $_POST['agencia'] != "") {
				include_once 'Contas.class.php';
				$conta = new Contas;	
				$con = $conta->conectar();
				$sel = "SELECT * FROM contas WHERE "
						. "agencia='" . $_POST['agencia'] . "' AND "
						. "conta='"   . $_POST['conta']   . "';";
				$qtd = $conta->selecionar($sel);

				if (!$qtd) {
					echo "Conta inexistente";
				} else {
					echo "ID da conta: " . $qtd;
		?>
				<h2>Escolha uma das opções</h2>
				<a href="?acao=depos&id=<?= $qtd; ?>">Depósito</a><br>
				<a href="?acao=saque&id=<?= $qtd; ?>">Saque</a><br>
				<a href="?acao=saldo&id=<?= $qtd; ?>">Saldo</a><br>
		<?php
				}
			}
		}
		else if ($acao == "conta") {
		?>
			<h2>Identifique a Conta</h2>
			<form action="?acao=movim" method="post">
				<label>Agência</label>
				<input type="text" name="agencia" size="10" required=""><br>
				<label>Conta</label>
				<input type="text" name="conta" size="20" required=""><br>
				<input type="submit" value="Confirmar" class="submit"><br>
			</form>
		<?php
		}
		else if ($acao == "abrir") {
		?>
			<h2>Formulário de Abertura de Contas</h2>
			<form action="Contas.php" method="post">
				<label>Cliente</label>
				<input type="text" name="nome" size="50" required=""><br>
				<label>Agência</label>
				<input type="text" name="agencia" size="10" required=""><br>
				<label>Conta</label>
				<input type="text" name="conta" size="20" required=""><br>
				<label>Saldo Inicial</label>
				<input type="text" name="saldo"><br>
				<input type="submit" value="Abrir Conta" class="submit"><br>
			</form>
		<?php
		}
		else if ($acao == "depos" || $acao == "saque") {
			if ($acao == "depos")
				echo "<h2>Depósito</h2>";
			else
				echo "<h2>Saque</h2>"
		?>
			<form action="Contas.php" method="post">
				<label>Valor</label>
				<input type="text"   name="valor" size="5"><br>
				<input type="hidden" name="tipo"  value="<?= $acao ?>"><br>
				<input type="hidden" name="id"    value="<?= $_GET['id'] ?>"><br>
				<input type="submit" value="Confirmar" class="submit"><br>
			</form>
		<?php
		}
		else if ($acao == "saldo") {	
			echo "<h2>Saldo</h2>";
		}
		else {
			echo "<h2>Ação Inválida</h2>";
		}

		if($acao != "") {
			echo "<br><a href='.' class='voltar'>voltar</a>";
		}
		?>
		</div>
	</body>
</html>