<html>
	<head>
		<meta charset="UTF-8">
		<title>Controle de Contas - Banco ETEC</title>
	</head>
	<body>
		<?php
		
		include_once ("Contas.class.php");
		$conta = new Contas;
		if(!isset($_POST['tipo'])) {
			$con = $conta->conectar();
			$conta->numAge   = $_POST['agencia'];
			$conta->numConta = $_POST['conta'];
			$conta->nome     = $_POST['nome'];
			$conta->saldo    = $_POST['saldo'];
			
			$sel = "SELECT * FROM contas WHERE nome='". $conta->nome 
					. "' AND agencia='". $conta->numAge . "'; ";
			
			$res = mysql_query($sel,$con) or die ("Erro");
			$qtd = mysql_num_rows($res);
			
			if ($qtd > 0) {
				echo "Conta já criada anteriormente ";
			}
			else {	
				$ins = "INSERT INTO contas (nome,agencia,conta,saldo) VALUES ('" 
						. $conta->nome ."','". $conta->numAge . "','". $conta->numConta 
						. "','". $conta->saldo . "');";
				mysql_query($ins,$con) or die ("erro: " . mysql_error($con));
			}
			mysql_close($con);
		}
		
//		echo $conta->exibeDados();
		
		if($_POST['tipo'] == "saque") {
			$conta->saque($_POST['valor'], $_POST['id']);		
		}
		else {
			$conta->deposito($_POST['valor'], $_POST['id']);
		}
		
//		echo $conta->exibeDados();
		?>
		<br><a href=".">inicio</a>
	</body>
</html>